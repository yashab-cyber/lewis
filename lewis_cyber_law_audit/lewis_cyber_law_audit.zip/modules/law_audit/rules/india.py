def get_india_rules():
    return [
        'Section 43 - Unauthorized Access',
        'Section 66 - Identity Theft',
        'Section 67 - Publishing Obscene Material',
        'Section 69 - Monitoring and Decryption by Government',
        'Section 70 - Protected Systems'
    ]
