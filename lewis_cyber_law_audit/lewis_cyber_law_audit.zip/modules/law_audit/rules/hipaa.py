def get_hipaa_rules():
    return [
        'HIPAA Privacy Rule',
        'HIPAA Security Rule',
        'HIPAA Breach Notification Rule',
        'Access Control',
        'Audit Controls'
    ]
