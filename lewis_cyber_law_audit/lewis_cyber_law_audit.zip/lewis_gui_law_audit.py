import tkinter as tk
from tkinter import filedialog, messagebox, ttk
import importlib.util
import os
import PyPDF2

options = {
    "India (IT Act)": "india",
    "GDPR": "gdpr",
    "ISO 27001": "iso_27001",
    "HIPAA": "hipaa",
    "PCI DSS": "pci_dss"
}
selected_option = "GDPR"
selected_file = ""

def load_rules(module_name):
    module_path = f"modules/law_audit/rules/{module_name}.py"
    spec = importlib.util.spec_from_file_location(module_name, module_path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return getattr(mod, f"get_{module_name}_rules")()

def browse_file():
    global selected_file
    selected_file = filedialog.askopenfilename(filetypes=[("PDF Files", "*.pdf")])
    file_label.config(text=selected_file)

def run_audit():
    global selected_option, selected_file
    region = options[selected_option]
    if not selected_file or not os.path.isfile(selected_file):
        messagebox.showerror("Error", "Please select a valid PDF file.")
        return

    try:
        rules = load_rules(region)
        with open(selected_file, "rb") as pdf_file:
            reader = PyPDF2.PdfReader(pdf_file)
            text = ""
            for page in reader.pages:
                text += page.extract_text()

        result_text.delete("1.0", tk.END)
        for rule in rules:
            check = "✅" if rule.lower() in text.lower() else "❌"
            result_text.insert(tk.END, f"{check} {rule}\n\n")
    except Exception as e:
        messagebox.showerror("Error", str(e))

root = tk.Tk()
root.title("LEWIS - Cyber Law Audit")
root.geometry("700x600")

tk.Label(root, text="Select Region:", font=("Segoe UI", 11)).pack(pady=5)
region_menu = ttk.Combobox(root, values=list(options.keys()), state="readonly")
region_menu.current(1)
region_menu.pack(pady=5)

def on_region_select(event):
    global selected_option
    selected_option = region_menu.get()

region_menu.bind("<<ComboboxSelected>>", on_region_select)

tk.Button(root, text="Browse PDF", command=browse_file).pack(pady=5)
file_label = tk.Label(root, text="", wraplength=650)
file_label.pack(pady=3)

tk.Button(root, text="Run Audit", command=run_audit).pack(pady=10)

result_text = tk.Text(root, wrap="word", bg="#0e0e0e", fg="#00ff88", font=("Consolas", 10))
result_text.pack(fill="both", expand=True, padx=10, pady=10)

root.mainloop()